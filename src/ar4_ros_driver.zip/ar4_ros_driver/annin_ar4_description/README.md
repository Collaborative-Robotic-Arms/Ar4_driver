# annin_ar4_description

This module contains the hardware description for the AR4 robot from Annin
Robotics. The URDFs were modified from the original ones. The main
modifications were to fix some of the joint rotation directions and to
specify revolute joints. Note that there is a seperate URDF for simulation
which contains the Gazebo plugins.
